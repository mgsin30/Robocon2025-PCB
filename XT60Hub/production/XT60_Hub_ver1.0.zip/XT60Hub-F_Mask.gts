G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.0*
G04 #@! TF.CreationDate,2025-04-10T20:15:44+09:00*
G04 #@! TF.ProjectId,XT60Hub,58543630-4875-4622-9e6b-696361645f70,ver1.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.0) date 2025-04-10 20:15:44*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,6.000000*%
%ADD11RoundRect,1.500000X-1.500000X1.500000X-1.500000X-1.500000X1.500000X-1.500000X1.500000X1.500000X0*%
%ADD12C,6.400000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J3*
X106550000Y-118250000D03*
D11*
X106550000Y-111050000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H1*
X74000000Y-101800000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J5*
X133150000Y-118250000D03*
D11*
X133150000Y-111050000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H2*
X113200000Y-101800000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J1*
X79950000Y-118250000D03*
D11*
X79950000Y-111050000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J4*
X119850000Y-118250000D03*
D11*
X119850000Y-111050000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H5*
X113200000Y-127500000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J2*
X93250000Y-118250000D03*
D11*
X93250000Y-111050000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H4*
X74000000Y-127500000D03*
G04 #@! TD*
G04 #@! TO.C,H6*
X152400000Y-127500000D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X152400000Y-101800000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J6*
X146450000Y-118250000D03*
D11*
X146450000Y-111050000D03*
G04 #@! TD*
M02*
