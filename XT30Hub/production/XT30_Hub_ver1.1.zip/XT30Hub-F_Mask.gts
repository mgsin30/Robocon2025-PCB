G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.4*
G04 #@! TF.CreationDate,2025-09-10T22:23:04+09:00*
G04 #@! TF.ProjectId,XT30Hub,58543330-4875-4622-9e6b-696361645f70,ver1.1*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4) date 2025-09-10 22:23:04*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.760000X-1.140000X1.140000X-1.140000X-1.140000X1.140000X-1.140000X1.140000X1.140000X0*%
%ADD11C,3.800000*%
%ADD12C,6.400000*%
%ADD13C,4.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X127250000Y-102800000D03*
D11*
X127250000Y-107800000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H6*
X182550000Y-115500000D03*
G04 #@! TD*
G04 #@! TO.C,H5*
X153250000Y-115500000D03*
G04 #@! TD*
G04 #@! TO.C,H2*
X153250000Y-95000000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J5*
X148140000Y-102800000D03*
D13*
X148140000Y-107800000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H4*
X123950000Y-115500000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J6*
X137720000Y-102800000D03*
D13*
X137720000Y-107800000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J2*
X179400000Y-102800000D03*
D13*
X179400000Y-107800000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J3*
X168980000Y-102800000D03*
D13*
X168980000Y-107800000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H3*
X182550000Y-95000000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J4*
X158560000Y-102800000D03*
D13*
X158560000Y-107800000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H1*
X123950000Y-95000000D03*
G04 #@! TD*
M02*
